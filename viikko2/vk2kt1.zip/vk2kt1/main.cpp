#include "Game.h"

    int main()
    {
        Game gameObject (10);
        gameObject.play();


        return 0;

    }





